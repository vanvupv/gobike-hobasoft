<?php

/*Disable edit code & plugin */



add_filter('xmlrpc_enabled', '__return_false');
add_filter('wp_headers', 'wptangtoc_remove_x_pingback');
add_filter('pings_open', '__return_false', 9999);
add_filter('pre_update_option_enable_xmlrpc', '__return_false');
add_filter('pre_option_enable_xmlrpc', '__return_zero');
function wptangtoc_remove_x_pingback($headers) {
unset($headers['X-Pingback'], $headers['x-pingback']);
return $headers;
}



function wp_version_remove_version() {
return '';
}
add_filter('the_generator', 'wp_version_remove_version');


global $product, $post;
add_action( 'init', 'hide_notice' );
function hide_notice() {
remove_action( 'admin_notices', 'flatsome_maintenance_admin_notice' );
}
register_sidebar( array(
	'name'          => __( 'Main Menu', 'flatsome' ),
	'id'            => 'menu-main',
	'before_widget' => '<div id="%1$s" class="%2$s">',
	'after_widget'  => '</div>',
	'before_title'  => '<span class="widget-title"><span>',
	'after_title'   => '</span></span>',
) );

register_sidebar( array(
	'name'          => __( 'Menu Tab', 'flatsome' ),
	'id'            => 'sidebar-brand',
	'before_widget' => '<div id="%1$s" class="%2$s menu-tab">',
	'after_widget'  => '</div>',
	'before_title'  => '<span class="widget-title"><span>',
	'after_title'   => '</span></span>',
) );

register_sidebar( array(
	'name'          => __( 'Bộ lọc sản phẩm', 'flatsome' ),
	'id'            => 'filter-sidebar',
	'before_widget' => '<div id="%1$s" class="%2$s">',
	'after_widget'  => '</div>',
	'before_title'  => '<span class="widget-title"><span>',
	'after_title'   => '</span></span>',
) );

function register_footer_menu_mobile() {
	register_nav_menus(
		array( 'footer-menu-mobile' => __( 'Footer Menu Mobile' ) )
	);}
add_action( 'init', 'register_footer_menu_mobile' );

function add_footer_menu_mobile() {
	wp_nav_menu( array( 'theme_location' => 'footer-menu-mobile', 'container_class' => 'footer-menu-mobile' ) );
}
add_action('flatsome_after_header', 'add_footer_menu_mobile');

function load_custom_wp_admin_style(){
    wp_register_style( 'custom_wp_admin_css', get_bloginfo('stylesheet_directory') . '/admin.css', false, '1.0.0' );
    wp_enqueue_style( 'custom_wp_admin_css' );
}
add_action('admin_enqueue_scripts', 'load_custom_wp_admin_style');

function load_custom_wp_admin_script() {
    wp_register_script( 'custom_wp_admin_script', get_bloginfo('stylesheet_directory') . '/my-themes.js', false, '1.0.0' );
    wp_enqueue_script( 'custom_wp_admin_script' );
}
add_action( 'wp_footer', 'load_custom_wp_admin_script' );





add_action('init', function() {
  // remove duotone support for Gutenberg blocks
  remove_filter('render_block', 'wp_render_duotone_support');
});

// Enable shortcodes in term description
add_filter( 'term_description', 'do_shortcode' );

// Add Icon Menu in Widget
add_filter('wp_nav_menu_args', 'wpex_ux_menu_icon');
add_filter('widget_nav_menu_args', 'wpex_ux_menu_icon');
function wpex_ux_menu_icon($args) {
   return array_merge( $args, array(
	  'walker' => new FlatsomeNavDropdown(),
   ) );
}
// Remove the Reviews and Additional information tab 
function woo_remove_product_tab($tabs) {
//	unset( $tabs['reviews'] );
	unset( $tabs['description'] ); 
	unset( $tabs['additional_information'] );  	
 	return $tabs;
}
add_filter( 'woocommerce_product_tabs', 'woo_remove_product_tab', 98);

// thay đổi form trang checkout
add_filter( 'woocommerce_checkout_fields' , 'custom_checkout_form' );
function custom_checkout_form( $fields ) {
    unset($fields['billing']['billing_postcode']); //Ẩn postCode
    unset($fields['billing']['billing_state']); //Ẩn bang hạt
    unset($fields['billing']['billing_country']);// Ẩn quốc gia
    unset($fields['billing']['billing_address_2']); //billing_company
    unset($fields['billing']['billing_company']);
    unset($fields['billing']['billing_last_name']);
    unset($fields['billing']['order_comments']);// Ẩn quốc gia
    unset($fields['billing']['billing_city']); //Ẩn select box chọn thành phố
    //unset($fields['billing']['billing_email']); 
     $fields['billing']['billing_first_name']['placeholder'] = "VD: Nguyễn Văn A";
     $fields['billing']['billing_phone']['placeholder'] = "0988xxxxxx";
     $fields['billing']['billing_email']['placeholder'] = "your_email@gmail.com"; 
    return $fields;
}
function custom_checkout_field_label( $fields ) {
    $fields['address_1']['label'] = 'Địa chỉ nhận hàng';
    $fields['first_name']['label'] = 'Họ và tên';
    return $fields;
}
add_filter( 'woocommerce_default_address_fields', 'custom_checkout_field_label' );

// To change add to cart text on single product page
add_filter( 'woocommerce_product_single_add_to_cart_text', 'woocommerce_custom_single_add_to_cart_text' ); 
function woocommerce_custom_single_add_to_cart_text() {
    echo '<i class="fas fa-cart-plus"></i> Thêm Vào Giỏ Hàng'  ; 
}
// Thay doi nut Order trang Thanh toan
function woocommerce_button_proceed_to_checkout() {
       $new_checkout_url = WC()->cart->get_checkout_url();
       ?>
       <a href="<?php echo $new_checkout_url; ?>" class="checkout-button button alt wc-forward">
	   <?php _e( 'Đặt mua ngay', 'woocommerce' ); ?></a>
<?php
}

/* Remove Image Sizes */
add_filter('intermediate_image_sizes_advanced','__return_false');

add_filter( 'woocommerce_variable_sale_price_html', 'lw_variable_product_price', 10, 2 );
add_filter( 'woocommerce_variable_price_html', 'lw_variable_product_price', 10, 2 );
function lw_variable_product_price( $v_price, $v_product ) {
// Sale Price
$v_prices = array( $v_product->get_variation_regular_price( 'min', true ), $v_product->get_variation_regular_price( 'max', true ) );
sort( $v_prices );
$v_saleprice = $v_prices[0]!==$v_prices[1] ? sprintf(__('%1$s','woocommerce'), wc_price( $v_prices[0] ) ) : wc_price( $v_prices[0] );
// Regular Price
$v_prices = array( $v_product->get_variation_price( 'min', true ), $v_product->get_variation_price( 'max', true ) );
$v_price = $v_prices[0]!==$v_prices[1] ? sprintf(__('%1$s', 'woocommerce'), wc_price( $v_prices[0] ) ) : wc_price( $v_prices[0] );
if ( $v_price !== $v_saleprice ) { 
	$v_price = '<ins>' . $v_price . $v_product->get_price_suffix() . '</ins><del><span>Giá niêm yết: </span>' . $v_saleprice.$v_product->get_price_suffix() . '</del>';
}
return $v_price;
}

add_filter( 'woocommerce_format_sale_price', 'invert_formatted_sale_price', 10, 3 );
function invert_formatted_sale_price( $price, $regular_price, $sale_price ) {
    return '<ins>' . ( is_numeric( $sale_price ) ? wc_price( $sale_price ) : $sale_price ) . '</ins><del><span>Giá niêm yết: </span>' . ( is_numeric( $regular_price ) ? wc_price( $regular_price ) : $regular_price ) . '</del>';
}
add_filter( 'woocommerce_variation_option_name', 'display_price_in_variation_option_name' );
function display_price_in_variation_option_name( $term ) {
    global $wpdb, $product;
    $result = $wpdb->get_col( "SELECT slug FROM {$wpdb->prefix}terms WHERE name = '$term'" );
    $term_slug = ( !empty( $result ) ) ? $result[0] : $term;
    $query = "SELECT postmeta.post_id AS product_id
                FROM {$wpdb->prefix}postmeta AS postmeta
                    LEFT JOIN {$wpdb->prefix}posts AS products ON ( products.ID = postmeta.post_id )
                WHERE postmeta.meta_key LIKE 'attribute_%'
                    AND postmeta.meta_value = '$term_slug'
                    AND products.post_parent = $product->id";
    $variation_id = $wpdb->get_col( $query );
    $parent = wp_get_post_parent_id( $variation_id[0] );
    if ( $parent > 0 ) {
        $_product = new WC_Product_Variation( $variation_id[0] );
        return $_product->get_price();
    }
    return $term;
}
// Add text before add to cart button
add_action( 'woocommerce_before_single_variation', 'xt_before_single_variation' );
function xt_before_single_variation(){
	global $post;
	$promotion_product = get_field( 'promotion_product' );
	$hotsale_product = get_field( 'hotsale_product' );
	$shipping = get_post_meta( $post->ID, 'shipping', true );
 	$select_shop_selected_option = get_field( 'select_shop' );
	$rows = get_field('product_linked');
	if ( get_field( 'installment' ) == 1 ) {
	echo '<span class="installment">Trả góp 0%</span>';
	}
	if( $rows ) {
		echo '<div class="linked-product">';
		foreach( $rows as $row ) {
			$link_linked_product = $row['link_linked_product'];
			$name_linked_product = $row['name_linked_product'];
			$price_linked_product = number_format( $row['price_linked_product'], 0, ',', '.' );
			echo '<a class="item-linked-product" href="' . $link_linked_product . '">';
			echo '<span>' . $name_linked_product . '</span>';
			echo '<strong>' . $price_linked_product . ' ₫</strong>' ;
			echo '</a>';
		}
		echo '</div>'; // linked-product
	}
	
	echo '<div class="promotion-info">';
	if( $hotsale_product ) { 
		echo '<div class="hotsale-product">' . $hotsale_product . '</div>';	
	}
	if( $promotion_product ) { 
		echo '<div class="promotion-product"><div class="promotion-icon"><i class="icon-gift"></i> Khuyến mãi</div><div>' . $promotion_product . '</div></div>';
	}
	echo '</div>'; // End promotion-info
}

// Add text before add to cart form
add_action( 'woocommerce_before_add_to_cart_form', 'xt_before_add_to_cart_form' );
function xt_before_add_to_cart_form(){
	global $post;
	$promotion_product = get_field( 'promotion_product' );
	$hotsale_product = get_field( 'hotsale_product' );
	$shipping = get_post_meta( $post->ID, 'shipping', true );
 	$select_shop_selected_option = get_field( 'select_shop' );
	$rows = get_field('product_linked');
	if ( get_field( 'installment' ) == 1 ) {
	echo '<span class="installment">Trả góp 0%</span>';
	}
}


/* Add quick buy button go to checkout after click */
add_action('woocommerce_after_add_to_cart_button','quickbuy_after_addtocart_button');
function quickbuy_after_addtocart_button(){
    global $product;
    ?>
    <button type="button" class="button buy_now_button"><?php _e('Mua ngay', 'ntx'); ?></button>
    <input type="hidden" name="is_buy_now" class="is_buy_now" value="0" autocomplete="off"/>
    <?php
}
add_filter('woocommerce_add_to_cart_redirect', 'redirect_to_checkout');
function redirect_to_checkout($redirect_url) {
    if (isset($_REQUEST['is_buy_now']) && $_REQUEST['is_buy_now']) {
        $redirect_url = wc_get_cart_url();
    }
    return $redirect_url;
}

function change_translate_text_multiple( $translated ) {
	$text = array(
		'Reply' => 'Bình luận',
		'Was this review helpful to you?' => 'Nhận xét này có hữu ích cho bạn?',
	);
	$translated = str_ireplace(  array_keys($text),  $text,  $translated );
	return $translated;
}
add_filter( 'gettext', 'change_translate_text_multiple', 20 );

function js_custom(){;?>
<script type="text/javascript">
    jQuery(document).ready(function ($) {
		jQuery('body').on('click', '.buy_now_button', function(e){
			e.preventDefault();
			var thisParent = jQuery(this).parents('form.cart');
			if(jQuery('.single_add_to_cart_button', thisParent).hasClass('disabled')) {
				jQuery('.single_add_to_cart_button', thisParent).trigger('click');
				return false;
			}
			thisParent.addClass('ntx-quickbuy');
			jQuery('.is_buy_now', thisParent).val('1');
			jQuery('.single_add_to_cart_button', thisParent).trigger('click');
		});
		
		jQuery(".menu .icon-angle-down, .product-footer-right .product.product-small .promotion, .product-footer-right .product.product-small .item-hotsale").remove();
		jQuery(".product-info h1.product-title").remove();
		jQuery(".product-type-variable .product-info>:is(.promotion-info, .linked-product)").remove();
		jQuery(".menu .sub-menu").removeClass("nav-dropdown nav-dropdown-default");
		jQuery("body").removeClass("nav-dropdown-has-arrow nav-dropdown-has-shadow");
				
		jQuery(function(){
			var current = location.pathname;
			jQuery('.item-linked-product').each(function(){
				var $this = $(this);
				if($this.attr('href').indexOf(current) !== -1){
					$this.addClass('active');
				}
			})
		});
    });
</script>
<?php }
add_action('wp_footer','js_custom');


class Auto_Save_Images{
 
    function __construct(){     
        
        add_filter( 'content_save_pre',array($this,'post_save_images') ); 
    }
    
    function post_save_images( $content ){
        if( ($_POST['save'] || $_POST['publish'] )){
            set_time_limit(240);
            global $post;
            $post_id=$post->ID;
            $preg=preg_match_all('/<img.*?src="(.*?)"/',stripslashes($content),$matches);
            if($preg){
                foreach($matches[1] as $image_url){
                    if(empty($image_url)) continue;
                    $pos=strpos($image_url,$_SERVER['HTTP_HOST']);
                    if($pos===false){
                        $res=$this->save_images($image_url,$post_id);
                        $replace=$res['url'];
                        $content=str_replace($image_url,$replace,$content);
                    }
                }
            }
        }
        remove_filter( 'content_save_pre', array( $this, 'post_save_images' ) );
        return $content;
    }
    
    function save_images($image_url,$post_id){
        $file=file_get_contents($image_url);
        $post = get_post($post_id);
        $posttitle = $post->post_title;
        $postname = sanitize_title($posttitle);
        $im_name = "$postname-$post_id.jpg";
        $res=wp_upload_bits($im_name,'',$file);
        $this->insert_attachment($res['file'],$post_id);
        return $res;
    }
    
    function insert_attachment($file,$id){
        $dirs=wp_upload_dir();
        $filetype=wp_check_filetype($file);
        $attachment=array(
            'guid'=>$dirs['baseurl'].'/'._wp_relative_upload_path($file),
            'post_mime_type'=>$filetype['type'],
            'post_title'=>preg_replace('/\.[^.]+$/','',basename($file)),
            'post_content'=>'',
            'post_status'=>'inherit'
        );
        $attach_id=wp_insert_attachment($attachment,$file,$id);
        $attach_data=wp_generate_attachment_metadata($attach_id,$file);
        wp_update_attachment_metadata($attach_id,$attach_data);
        return $attach_id;
    }
}
new Auto_Save_Images();