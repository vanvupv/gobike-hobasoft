<?php
/*
Template name: Page - Full Width
*/
get_header(); ?>

<?php do_action( 'flatsome_before_page' ); ?>

<div id="content" role="main" class="content-area">
	<?php if ( is_front_page() ) { ?>
	<div class="banner-home">
		<div class="container chien">
			<div class="row">
				<div class="col large-3 hide-for-medium box_left">
					<div class="menu-top">
						<?php if ( is_active_sidebar( 'menu-main' ) ) : ?>
						<?php dynamic_sidebar( 'menu-main' ); ?>
						<?php endif; ?>
					</div>
				</div>
				<div class="col slider-top large-7 medium-12 box_center"><div class="swiper-container">
					<?php 
						$rows = get_field('slider_top');
						if( $rows ) {
							echo '<div class="mySwiper2">
							  <div class="swiper-wrapper">
								';
							foreach( $rows as $row ) {
								$image = $row['image_slide'];
								$link_url = $row['link_url'];
								echo '<div class="swiper-slide">';
									echo '<a href="' . $link_url . '">' ;
									echo '<img src="' . $image['url'] . '" /></a>';
								echo '</div>';
							}
							echo '</div>
							  <div class="swiper-button-next"></div>
							  <div class="swiper-button-prev"></div>
							</div>';
							echo '<div class="mySwiper">
							  <div class="swiper-wrapper">';
							foreach( $rows as $row ) {
									echo '<div class="swiper-slide">';
									echo $row['title_slide'] ;
									echo '<br>';
									echo $row['des_slide'] ;
									echo '</div>';
							}
							echo '</div></div>';
						} ?>
		<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
		<script>
		  var swiper = new Swiper(".mySwiper", {
			spaceBetween: 0,
			slidesPerView: 5,
			freeMode: false,
			allowTouchMove: false,
			watchSlidesVisibility: true,
			watchSlidesProgress: true,
		  });
		  var swiper2 = new Swiper(".mySwiper2", {
			spaceBetween: 0,
			loop: true,
			autoplay: {
			  delay: 2500,
			  disableOnInteraction: false,
			},
			navigation: {
			  nextEl: ".swiper-button-next",
			  prevEl: ".swiper-button-prev",
			},
			thumbs: {
			  swiper: swiper,
			},
		  });
		</script>
				</div></div>
				<div class="col large-3 hide-for-medium box_right">
					<?php 
						$rows = get_field('image_ads_right');
						if( $rows ) {
							echo '<div class="image-ads">';
							foreach( $rows as $row ) {
								$image = $row['image_ads'];
								$link_url = $row['link_url_img_ads'];
								echo '<div class="item-image-ads">';
									echo '<a href="' . $link_url . '">' ;
									echo '<img src="' . $image['url'] . '" /></a>';
								echo '</div>';
							}
							echo '</div>';
						} ?>
				</div>
				<div class="menu-mobile">
						<?php if ( is_active_sidebar( 'menu-mobile' ) ) : ?>
						<?php dynamic_sidebar( 'menu-mobile' ); ?>
						<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
	<?php } ?>
	
		<?php while ( have_posts() ) : the_post(); ?>
			<?php the_content(); ?>
		<?php endwhile; // end of the loop. ?>
		
</div>

<?php do_action( 'flatsome_after_page' ); ?>

<?php get_footer(); ?>
